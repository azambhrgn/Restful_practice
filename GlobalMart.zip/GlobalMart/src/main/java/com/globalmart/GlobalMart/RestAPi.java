package com.globalmart.GlobalMart;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.database.DBUtility;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

/**
 * Class to cover all rest API
 * @author Azam khan
 *url - http://localhost:8080/GlobalMart/webapi/gmart/*
 */
@Path("gmart")
public class RestAPi {
	
	
	
	/**
	 * Add ne wProduct
	 * @param product
	 * @return
	 */
	@POST
	@Path("addproduct")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addProduct(Product product) {
		int ret = 0;
		DBUtility db = new DBUtility();
		Connection conn = db.createConnection();
		//String result = "Product created : " + product.getName();
		try {
			ret = db.addProduct(conn, product);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String result = null;
		if(ret == 1) {
			result = "Created : true";
		} else {
			result = "Created : false";
		}
		return Response.status(201).entity(result).build();
	    
	}
	
	
	
	
	/**
	 * Get product of given type
	 * @param type
	 * @return
	 */
	@GET
	@Path("getpbytype/{type}")
	@Produces("application/json")
	public Response getProductbyType(@PathParam("type") String type) {
		DBUtility db = new DBUtility();
		Connection conn = db.createConnection();
		
		System.out.println("Inside method");
		ArrayList<Product> list = null;
		try {
			list = db.getProductByType(conn, type);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.closeConnection(conn);
		Gson gson = new Gson();
		
		return Response.status(201).entity(gson.toJson(list)).build();

	}
	
	
	
	
	/**
	 * Get all product list
	 * @return
	 */
	@GET
	@Path("getallproduct")
	@Produces("application/json")
	public Response getAllProduct() {
		DBUtility db = new DBUtility();
		Connection conn = db.createConnection();
		
		//System.out.println("Inside method");
		ArrayList<Product> list = null;
		try {
			list = db.getAllProduct(conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.closeConnection(conn);
		Gson gson = new Gson();
		
		return Response.status(201).entity(gson.toJson(list)).build();

	}
	
	
	/**
	 * To get price of given Product id
	 * @param id
	 * @return
	 */
	@GET
	@Path("getprice/{id}")
	@Produces("application/json")
	public Response getPrice(@PathParam("id") int id) {
		DBUtility db = new DBUtility();
		Connection conn = db.createConnection();
		
		//System.out.println("Inside method");
		Float price = null;
		try {
			price = db.getPrice(conn, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		db.closeConnection(conn);
		
		JsonObject json = new JsonObject();
		json.addProperty("price", price);
		//Gson gson = new Gson();
		
		return Response.status(201).entity(json.toString()).build();

	}
	
	/**
	 * To delete Product
	 * @param id
	 * @return
	 */
	@DELETE
	@Path("deletebyid/{id}")
	@Produces("application/json")
	public Response deleteProduct(@PathParam("id") int id){
		DBUtility db = new DBUtility();
		Connection conn = db.createConnection();
		
		int ret = 0;
		
		try {
			ret = db.deleteProduct(conn, id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		JsonObject json = new JsonObject();
		if(ret == 1){
			json.addProperty("deleted", "true");
		} else {
			json.addProperty("deleted", "false");
		}
		
		
		return Response.status(201).entity(json.toString()).build();
	}

}


