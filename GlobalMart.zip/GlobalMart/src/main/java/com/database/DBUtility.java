package com.database;

import java.sql.*;
import java.util.ArrayList;

import com.globalmart.GlobalMart.Product;



public class DBUtility {

	private static final String PWD = "root";
	private static final String USER = "root";
	private static final String URL = "jdbc:mysql://localhost:3306/";
	private static final String DB = "gmart";

	/**
	 * Create connection
	 * @return
	 */
	public Connection createConnection() {
		Connection conn = null;

		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			conn = DriverManager.getConnection(URL + DB, USER, PWD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return conn;
	}

	/**
	 * Add new Product
	 * @param conn
	 * @param product
	 * @return
	 * @throws SQLException
	 */
	public int addProduct(Connection conn, Product product) throws SQLException {

		String query = "INSERT INTO PRODUCTS (name,type,price,description,quantity) VALUES (?,?,?,?,?)";

		PreparedStatement ps = null;
		int ret = 0;
		try {
			ps = (PreparedStatement) conn.prepareStatement(query);

			ps.setString(1, product.getName());
			ps.setString(2, product.getType());
			ps.setFloat(3, product.getPrice());
			ps.setString(4, product.getDescription());
			ps.setInt(5, product.getQuantity());

			ret = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (ps != null) {
				ps.close();
			}
		}

		return ret;
	}

	/**
	 * Get product of given type
	 * @param conn
	 * @param type
	 * @return
	 * @throws SQLException 
	 */
	public ArrayList<Product> getProductByType(Connection conn, String type) throws SQLException {
		ArrayList<Product> product = new ArrayList<>();

		String query = "SELECT * FROM PRODUCTS WHERE TYPE = ?";
		PreparedStatement ps = null;
		
		try {
			ps = (PreparedStatement) conn.prepareStatement(query);
			
			ps.setString(1, type);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next()){
				Product prod = new Product();
				prod.setId(rs.getInt("id"));
				prod.setName(rs.getNString("name"));
				prod.setType(rs.getString("type"));
				prod.setPrice(rs.getFloat("price"));
				prod.setDescription(rs.getString("description"));
				prod.setQuantity(rs.getInt("quantity"));
				
				product.add(prod);
			}
			
			
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (ps != null) {
				ps.close();
			}
		}

		return product;
	}
	
	/**
	 * get All product
	 * @param conn
	 * @param type
	 * @return
	 * @throws SQLException 
	 */
	public ArrayList<Product> getAllProduct(Connection conn) throws SQLException {
		ArrayList<Product> product = new ArrayList<>();

		String query = "SELECT * FROM PRODUCTS";
		PreparedStatement ps = null;
		
		try {
			ps = (PreparedStatement) conn.prepareStatement(query);
			
			ResultSet rs =  ps.executeQuery();
			
			while(rs.next()){
				Product prod = new Product();
				prod.setId(rs.getInt("id"));
				prod.setName(rs.getNString("name"));
				prod.setType(rs.getString("type"));
				prod.setPrice(rs.getFloat("price"));
				prod.setDescription(rs.getString("description"));
				prod.setQuantity(rs.getInt("quantity"));
				
				product.add(prod);
			}
			
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (ps != null) {
				ps.close();
			}
		}

		return product;
	}
	
	/**
	 * Get Price of given product
	 * @param conn
	 * @param id
	 * @return
	 * @throws SQLException 
	 */
	public Float getPrice(Connection conn,int id) throws SQLException{
		Float price = null;
		
		String query = "SELECT PRICE FROM PRODUCTS WHERE ID = ?";
		PreparedStatement ps = null;
		
		try {
			ps = (PreparedStatement) conn.prepareStatement(query);
			
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()){
				price = rs.getFloat(1);
			}
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (ps != null) {
				ps.close();
			}
		}
		
		
		return price;
	}
	
	/**
	 * Delete a product
	 * @param conn
	 * @param id
	 * @return
	 * @throws SQLException 
	 */
	public int deleteProduct(Connection conn, int id) throws SQLException{
		
		int rows = 0;
		String query = "DELETE FROM PRODUCTS WHERE ID = ?";
		PreparedStatement ps = null;
		
		try {
			ps = (PreparedStatement) conn.prepareStatement(query);
			
			ps.setInt(1, id);
			
			rows = ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			if (ps != null) {
				ps.close();
			}
		}
		
		return rows;
		
	}
	
	
	
	
	/**
	 * Close connection
	 * @param conn
	 */
	public void closeConnection(Connection conn) {
		// TODO Auto-generated method stub
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
